export const APP_NAME = 'SwarWave';
export const APP_TAGLINE = 'Privacy-first music, video, and live radio hub';
export const APP_DESCRIPTION = 'SwarWave is a privacy-first music player, video player, and live radio hub with playlists, offline cache, PiP, background controls, and zero tracking.';
export const APP_AUTHOR = 'Sudhir Kumar';
export const APP_REPO_URL = 'https://github.com/wherewhere/PrivMITLab-Music-Radio';
export const APP_AUTHOR_URL = 'https://github.com/wherewhere';
export const APP_COPYRIGHT = '2026';